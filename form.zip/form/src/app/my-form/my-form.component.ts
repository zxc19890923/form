import {Component, OnInit} from '@angular/core';
// 表单
import {FormControl, FormGroup, FormBuilder} from "@angular/forms";

@Component({
    selector: 'app-my-form',
    templateUrl: './my-form.component.html',
    styleUrls: ['./my-form.component.css']
})
// 默认使用formGroup, formContrl module引入formsModule即可，如果使用formBuilder module中还需引入 reactiveFormsModule
export class MyFormComponent implements OnInit {
    public myForm: any;    // formGroup 包含多个 formControl   // formBuilder可以创建formGroup(formBuilder.group());

    constructor(fb: FormBuilder) {
        this.myForm = fb.group({
            'sku': ['ssdkjfs']
        });
    }

    ngOnInit() {
    }

    formSubmit(ctl) {
        console.log(ctl);
    }
}
